import React, { useMemo } from 'react';


function CustomComponent({ a, b, onCalculation }) {
  const computedValue = useMemo(() => {
    const result = a + b;
    onCalculation(result);
    return result;
  }, [a, b, onCalculation]);

  return (
    <div>
      <p>Computed Value: {computedValue}</p>
    </div>
  );
}

function App() {
  const handleCalculation = (result) => {
    console.log('Calculated Value:', result);
  };

  return (
    <div>
      <h1>Prop ile bir callback geçmek</h1>
      <CustomComponent a={5} b={3} onCalculation={handleCalculation} />
    </div>
  );
}

export default App;